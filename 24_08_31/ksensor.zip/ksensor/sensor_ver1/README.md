# DHT
- DHTStable라이브러리 아두이노에서 다운해서 사용
