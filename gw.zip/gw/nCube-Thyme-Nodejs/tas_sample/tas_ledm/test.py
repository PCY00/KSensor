import sys
import os

def main():
    if len(sys.argv) != 2:
        print("Usage: python_script.py <data>")
        sys.exit(1)

    data = sys.argv[1]
    file_path = '/home/jetson/Desktop/output.txt'

    # Write data to a text file
    try:
        with open(file_path, 'w') as file:
            file.write(data)
        print(f"Data written to {file_path}: {data}")
    except IOError as e:
        print(f"Error writing to file {file_path}: {e}")

if __name__ == "__main__":
    main()

